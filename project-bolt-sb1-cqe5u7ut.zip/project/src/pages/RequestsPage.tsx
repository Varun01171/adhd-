import React, { useState } from 'react';
import { Check, X, Clock, User, ArrowRight, MessageSquare, Calendar } from 'lucide-react';
import { useData } from '../context/DataContext';

export default function RequestsPage() {
  const [activeTab, setActiveTab] = useState<'received' | 'sent'>('received');
  const { getReceivedRequests, getSentRequests, respondToRequest } = useData();

  const receivedRequests = getReceivedRequests();
  const sentRequests = getSentRequests();

  const handleResponse = (requestId: string, status: 'accepted' | 'rejected') => {
    respondToRequest(requestId, status);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30';
      case 'accepted':
        return 'bg-green-500/20 text-green-300 border border-green-500/30';
      case 'rejected':
        return 'bg-red-500/20 text-red-300 border border-red-500/30';
      default:
        return 'bg-white/10 text-white/60 border border-white/20';
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 fade-in">
      <div className="mb-8">
        <h1 className="text-5xl font-black text-white mb-4">
          <span className="gradient-text">Skill Swap</span> Requests
        </h1>
        <p className="text-xl text-white/70">Manage your incoming and outgoing requests</p>
      </div>

      {/* Tabs */}
      <div className="glass-card mb-8">
        <div className="border-b border-white/10">
          <nav className="flex">
            <button
              onClick={() => setActiveTab('received')}
              className={`flex-1 py-6 px-8 text-center font-bold text-lg transition-all duration-200 ${
                activeTab === 'received'
                  ? 'text-blue-400 border-b-2 border-blue-400 bg-blue-500/10'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Received Requests ({receivedRequests.length})
            </button>
            <button
              onClick={() => setActiveTab('sent')}
              className={`flex-1 py-6 px-8 text-center font-bold text-lg transition-all duration-200 ${
                activeTab === 'sent'
                  ? 'text-blue-400 border-b-2 border-blue-400 bg-blue-500/10'
                  : 'text-white/60 hover:text-white hover:bg-white/5'
              }`}
            >
              Sent Requests ({sentRequests.length})
            </button>
          </nav>
        </div>

        <div className="p-8">
          {activeTab === 'received' && (
            <div className="space-y-6">
              {receivedRequests.length === 0 ? (
                <div className="text-center py-20">
                  <div className="w-32 h-32 bg-white/5 rounded-3xl flex items-center justify-center mx-auto mb-8">
                    <MessageSquare className="text-white/40" size={48} />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-4">No requests yet</h3>
                  <p className="text-white/60 text-lg">
                    When people want to learn from you, their requests will appear here
                  </p>
                </div>
              ) : (
                receivedRequests.map((request) => (
                  <div key={request.id} className="glass-card p-8 hover:bg-white/10 transition-all duration-200">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4 mb-6">
                          <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center">
                            <User className="text-white" size={24} />
                          </div>
                          <div>
                            <h3 className="text-2xl font-bold text-white">
                              {request.fromUserName}
                            </h3>
                            <div className="flex items-center text-white/60 text-sm mt-1">
                              <Calendar size={14} className="mr-1" />
                              {new Date(request.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>

                        <div className="glass-card p-6 mb-6">
                          <div className="flex items-center justify-center space-x-6">
                            <div className="text-center">
                              <p className="text-white/60 text-sm mb-2">They want to learn</p>
                              <span className="skill-tag skill-offered font-semibold">
                                {request.skillOffered}
                              </span>
                            </div>
                            <ArrowRight className="text-white/40" size={24} />
                            <div className="text-center">
                              <p className="text-white/60 text-sm mb-2">In exchange for</p>
                              <span className="skill-tag skill-wanted font-semibold">
                                {request.skillWanted}
                              </span>
                            </div>
                          </div>
                        </div>

                        {request.message && (
                          <div className="glass-card p-4 mb-6">
                            <p className="text-white/80">
                              <span className="font-semibold text-white">Message:</span> {request.message}
                            </p>
                          </div>
                        )}
                      </div>

                      <div className="ml-8 flex flex-col items-end space-y-4">
                        <span className={`px-4 py-2 rounded-xl text-sm font-semibold ${getStatusColor(request.status)}`}>
                          {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                        </span>
                        
                        {request.status === 'pending' && (
                          <div className="flex space-x-3">
                            <button
                              onClick={() => handleResponse(request.id, 'accepted')}
                              className="flex items-center space-x-2 px-6 py-3 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-all duration-200 font-semibold"
                            >
                              <Check size={18} />
                              <span>Accept</span>
                            </button>
                            <button
                              onClick={() => handleResponse(request.id, 'rejected')}
                              className="flex items-center space-x-2 px-6 py-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-all duration-200 font-semibold"
                            >
                              <X size={18} />
                              <span>Decline</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'sent' && (
            <div className="space-y-6">
              {sentRequests.length === 0 ? (
                <div className="text-center py-20">
                  <div className="w-32 h-32 bg-white/5 rounded-3xl flex items-center justify-center mx-auto mb-8">
                    <Clock className="text-white/40" size={48} />
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-4">No requests sent</h3>
                  <p className="text-white/60 text-lg">
                    Start by discovering skills and sending your first swap request
                  </p>
                </div>
              ) : (
                sentRequests.map((request) => (
                  <div key={request.id} className="glass-card p-8">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-4 mb-6">
                          <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center">
                            <User className="text-white" size={24} />
                          </div>
                          <div>
                            <h3 className="text-2xl font-bold text-white">
                              {request.toUserName}
                            </h3>
                            <div className="flex items-center text-white/60 text-sm mt-1">
                              <Calendar size={14} className="mr-1" />
                              Sent {new Date(request.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>

                        <div className="glass-card p-6 mb-6">
                          <div className="flex items-center justify-center space-x-6">
                            <div className="text-center">
                              <p className="text-white/60 text-sm mb-2">You offered to teach</p>
                              <span className="skill-tag skill-offered font-semibold">
                                {request.skillOffered}
                              </span>
                            </div>
                            <ArrowRight className="text-white/40" size={24} />
                            <div className="text-center">
                              <p className="text-white/60 text-sm mb-2">To learn</p>
                              <span className="skill-tag skill-wanted font-semibold">
                                {request.skillWanted}
                              </span>
                            </div>
                          </div>
                        </div>

                        {request.message && (
                          <div className="glass-card p-4">
                            <p className="text-white/80">
                              <span className="font-semibold text-white">Your message:</span> {request.message}
                            </p>
                          </div>
                        )}
                      </div>

                      <span className={`px-4 py-2 rounded-xl text-sm font-semibold ${getStatusColor(request.status)}`}>
                        {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}