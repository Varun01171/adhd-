import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Clock, Star, MessageSquare, Calendar, Award } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export default function UserDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const { getAllUsers } = useData();

  const otherUser = getAllUsers().find(u => u.id === id);

  if (!otherUser) {
    return (
      <div className="min-h-screen bg-mesh text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">User not found</h1>
          <Link to="/discovery" className="btn-primary">
            ← Back to Discovery
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <Link
          to="/discovery"
          className="btn-ghost flex items-center space-x-2"
        >
          <ArrowLeft size={20} />
          <span>Back to Discovery</span>
        </Link>
        <Link
          to={`/request-form/${otherUser.id}`}
          className="btn-primary flex items-center space-x-2 px-8 py-4 text-lg"
        >
          <MessageSquare size={20} />
          <span>Send Request</span>
        </Link>
      </div>

      {/* User Profile */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - User Info */}
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card p-8">
            <div className="flex items-start space-x-6 mb-8">
              <img
                src={otherUser.profileImage}
                alt={otherUser.name}
                className="w-32 h-32 rounded-3xl object-cover border-4 border-white/20"
              />
              <div className="flex-1">
                <h1 className="text-4xl font-black text-white mb-4">{otherUser.name}</h1>
                <div className="flex items-center space-x-6 text-white/70 mb-4">
                  <div className="flex items-center space-x-2">
                    <MapPin size={18} />
                    <span>{otherUser.location}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock size={18} />
                    <span>Available {otherUser.availability}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Star size={18} className="text-yellow-400 fill-current" />
                    <span className="text-yellow-400 font-bold">{otherUser.rating.toFixed(1)}/5.0</span>
                  </div>
                </div>
                {otherUser.bio && (
                  <p className="text-white/80 text-lg leading-relaxed">{otherUser.bio}</p>
                )}
              </div>
            </div>
          </div>

          {/* Skills Section */}
          <div className="glass-card p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Skills & Expertise</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-bold text-emerald-400 mb-4 flex items-center">
                  <Award className="mr-2" size={20} />
                  Skills Offered
                </h3>
                <div className="space-y-3">
                  {otherUser.skillsOffered.map((skill: string) => (
                    <div key={skill} className="skill-tag skill-offered text-base font-semibold">
                      {skill}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-purple-400 mb-4 flex items-center">
                  <Calendar className="mr-2" size={20} />
                  Skills Wanted
                </h3>
                <div className="space-y-3">
                  {otherUser.skillsWanted.map((skill: string) => (
                    <div key={skill} className="skill-tag skill-wanted text-base font-semibold">
                      {skill}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Potential Matches */}
          <div className="glass-card p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Skill Match Analysis</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-6">
                <h3 className="text-emerald-400 font-bold mb-3">You Can Teach Them</h3>
                <div className="space-y-2">
                  {user?.skillsOffered.filter(skill => 
                    otherUser.skillsWanted.includes(skill)
                  ).map(skill => (
                    <div key={skill} className="skill-tag skill-offered">
                      {skill}
                    </div>
                  ))}
                  {user?.skillsOffered.filter(skill => 
                    otherUser.skillsWanted.includes(skill)
                  ).length === 0 && (
                    <p className="text-white/60 italic">No matching skills</p>
                  )}
                </div>
              </div>

              <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-6">
                <h3 className="text-purple-400 font-bold mb-3">They Can Teach You</h3>
                <div className="space-y-2">
                  {otherUser.skillsOffered.filter((skill: string) => 
                    user?.skillsWanted.includes(skill)
                  ).map((skill: string) => (
                    <div key={skill} className="skill-tag skill-wanted">
                      {skill}
                    </div>
                  ))}
                  {otherUser.skillsOffered.filter((skill: string) => 
                    user?.skillsWanted.includes(skill)
                  ).length === 0 && (
                    <p className="text-white/60 italic">No matching skills</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Actions & Stats */}
        <div className="space-y-8">
          <div className="glass-card p-8 text-center">
            <h2 className="text-xl font-bold text-white mb-6">Connect</h2>
            <Link
              to={`/request-form/${otherUser.id}`}
              className="btn-primary w-full py-4 text-lg mb-4"
            >
              Send Skill Request
            </Link>
            <p className="text-white/60 text-sm">
              Start a skill exchange conversation
            </p>
          </div>

          <div className="glass-card p-8">
            <h2 className="text-xl font-bold text-white mb-6">Profile Stats</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-white/60">Rating</span>
                <div className="flex items-center space-x-1">
                  <Star className="text-yellow-400 fill-current" size={16} />
                  <span className="text-yellow-400 font-bold">{otherUser.rating.toFixed(1)}</span>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Skills Offered</span>
                <span className="text-emerald-400 font-bold">{otherUser.skillsOffered.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Skills Wanted</span>
                <span className="text-purple-400 font-bold">{otherUser.skillsWanted.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Availability</span>
                <span className="text-blue-400 font-bold capitalize">{otherUser.availability}</span>
              </div>
            </div>
          </div>

          <div className="glass-card p-8">
            <h2 className="text-xl font-bold text-white mb-4">Why Connect?</h2>
            <div className="space-y-3 text-sm text-white/70">
              <p>• Expand your skill set through exchange</p>
              <p>• Learn from experienced practitioners</p>
              <p>• Build meaningful professional relationships</p>
              <p>• Grow together in a supportive community</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}