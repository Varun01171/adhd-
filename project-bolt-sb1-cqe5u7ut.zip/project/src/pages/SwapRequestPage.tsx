import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Filter, Star, MapPin, Clock, LogOut, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export default function SwapRequestPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [availabilityFilter, setAvailabilityFilter] = useState('all');
  const { user, logout } = useAuth();
  const { getAllUsers } = useData();

  const allUsers = getAllUsers();

  const filteredUsers = allUsers.filter(otherUser => {
    const matchesSearch = searchTerm === '' || 
      otherUser.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      otherUser.skillsOffered.some((skill: string) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      otherUser.skillsWanted.some((skill: string) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      otherUser.location.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesAvailability = availabilityFilter === 'all' || otherUser.availability === availabilityFilter;

    return matchesSearch && matchesAvailability;
  });

  return (
    <div className="min-h-screen bg-mesh text-white">
      {/* Header */}
      <div className="glass-effect border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-lg">S</span>
              </div>
              <span className="text-2xl font-bold gradient-text">SkillSwap</span>
            </div>
            
            <div className="flex items-center space-x-6">
              <span className="text-white/80 border-b-2 border-blue-400 pb-1">Swap Request</span>
              <Link to="/profile" className="text-white/60 hover:text-white transition-colors">
                Profile
              </Link>
              <button
                onClick={logout}
                className="flex items-center space-x-2 text-white/60 hover:text-red-400 transition-colors"
              >
                <LogOut size={18} />
                <span>Logout</span>
              </button>
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold">{user?.name?.charAt(0)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="flex items-center space-x-4">
            <Filter className="text-white/60" size={20} />
            <select
              value={availabilityFilter}
              onChange={(e) => setAvailabilityFilter(e.target.value)}
              className="input-modern min-w-[160px]"
            >
              <option value="all">All Availability</option>
              <option value="weekends">Weekends</option>
              <option value="evenings">Evenings</option>
              <option value="weekdays">Weekdays</option>
              <option value="flexible">Flexible</option>
            </select>
          </div>
          
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
            <input
              type="text"
              placeholder="Search users, skills, or locations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-modern w-full pl-12"
            />
          </div>
        </div>

        {/* User Cards */}
        <div className="space-y-6">
          {filteredUsers.map((otherUser) => (
            <div key={otherUser.id} className="glass-effect rounded-3xl p-8 card-hover">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-8">
                  <div className="relative">
                    <img
                      src={otherUser.profileImage}
                      alt={otherUser.name}
                      className="w-24 h-24 rounded-2xl object-cover border-2 border-white/20"
                    />
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full border-2 border-slate-900 flex items-center justify-center">
                      <div className="w-3 h-3 bg-white rounded-full"></div>
                    </div>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-3xl font-bold mb-2">{otherUser.name}</h3>
                      <div className="flex items-center space-x-4 text-white/60">
                        <div className="flex items-center space-x-1">
                          <MapPin size={16} />
                          <span>{otherUser.location}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock size={16} />
                          <span>{otherUser.availability}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="text-emerald-400 text-sm font-medium">Skills Offered →</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {otherUser.skillsOffered.map((skill: string) => (
                          <span key={skill} className="skill-tag skill-offered">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="text-purple-400 text-sm font-medium">Skills Wanted →</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {otherUser.skillsWanted.map((skill: string) => (
                          <span key={skill} className="skill-tag skill-wanted">
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="text-right space-y-6">
                  <Link
                    to={`/user/${otherUser.id}`}
                    className="btn-primary block text-center"
                  >
                    Request Swap
                  </Link>
                  <div className="flex items-center space-x-2 text-white/60">
                    <Star className="text-yellow-400 fill-current" size={16} />
                    <span className="text-sm">Rating {otherUser.rating}/5</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredUsers.length === 0 && (
          <div className="text-center py-20">
            <div className="w-24 h-24 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <User className="text-white/40" size={40} />
            </div>
            <h3 className="text-2xl font-bold text-white/80 mb-2">No users found</h3>
            <p className="text-white/60">
              Try adjusting your search criteria or explore all available users
            </p>
          </div>
        )}
      </div>
    </div>
  );
}