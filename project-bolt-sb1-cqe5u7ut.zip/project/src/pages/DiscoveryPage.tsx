import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Clock, Star, MessageSquare, Filter, Users } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useAuth } from '../context/AuthContext';

export default function DiscoveryPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterBy, setFilterBy] = useState('all');
  const { getAllUsers } = useData();
  const { user } = useAuth();
  const allUsers = getAllUsers();

  const filteredUsers = allUsers.filter(otherUser => {
    const matchesSearch = searchTerm === '' || 
      otherUser.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      otherUser.skillsOffered.some((skill: string) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      otherUser.skillsWanted.some((skill: string) => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
      otherUser.location.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter = filterBy === 'all' || 
      (filterBy === 'can-teach' && otherUser.skillsOffered.some((skill: string) => 
        user?.skillsWanted.includes(skill)
      )) ||
      (filterBy === 'want-to-learn' && otherUser.skillsWanted.some((skill: string) => 
        user?.skillsOffered.includes(skill)
      ));

    return matchesSearch && matchesFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 fade-in">
      <div className="mb-8">
        <h1 className="text-5xl font-black text-white mb-4">
          <span className="gradient-text">Discover</span> Skills
        </h1>
        <p className="text-xl text-white/70">Find amazing people to learn from and teach</p>
      </div>

      {/* Search and Filters */}
      <div className="glass-card p-8 mb-8">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
            <input
              type="text"
              placeholder="Search by name, skills, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input-modern w-full pl-12 text-lg py-4"
            />
          </div>
          <div className="flex items-center space-x-4">
            <Filter className="text-white/60" size={20} />
            <select
              value={filterBy}
              onChange={(e) => setFilterBy(e.target.value)}
              className="input-modern min-w-[200px] text-lg py-4"
            >
              <option value="all">All Users</option>
              <option value="can-teach">Can Teach Me</option>
              <option value="want-to-learn">Want to Learn From Me</option>
            </select>
          </div>
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredUsers.map((otherUser) => (
          <div key={otherUser.id} className="glass-card-hover p-8 slide-up">
            <div className="flex items-center space-x-4 mb-6">
              <img
                src={otherUser.profileImage}
                alt={otherUser.name}
                className="w-20 h-20 rounded-2xl object-cover border-2 border-white/20"
              />
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-white">{otherUser.name}</h3>
                <div className="flex items-center text-white/60 text-sm mt-1">
                  <MapPin size={14} className="mr-1" />
                  {otherUser.location}
                </div>
                <div className="flex items-center text-yellow-400 text-sm mt-1">
                  <Star size={14} className="mr-1 fill-current" />
                  {otherUser.rating.toFixed(1)}
                </div>
              </div>
            </div>

            {otherUser.bio && (
              <p className="text-white/70 text-sm mb-6 line-clamp-3">{otherUser.bio}</p>
            )}

            <div className="mb-6">
              <h4 className="text-sm font-bold text-emerald-400 mb-3">Can Teach</h4>
              <div className="flex flex-wrap gap-2">
                {otherUser.skillsOffered.slice(0, 3).map((skill: string) => (
                  <span key={skill} className="skill-tag skill-offered text-xs">
                    {skill}
                  </span>
                ))}
                {otherUser.skillsOffered.length > 3 && (
                  <span className="skill-tag bg-white/10 text-white/60 text-xs">
                    +{otherUser.skillsOffered.length - 3}
                  </span>
                )}
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-sm font-bold text-purple-400 mb-3">Wants to Learn</h4>
              <div className="flex flex-wrap gap-2">
                {otherUser.skillsWanted.slice(0, 3).map((skill: string) => (
                  <span key={skill} className="skill-tag skill-wanted text-xs">
                    {skill}
                  </span>
                ))}
                {otherUser.skillsWanted.length > 3 && (
                  <span className="skill-tag bg-white/10 text-white/60 text-xs">
                    +{otherUser.skillsWanted.length - 3}
                  </span>
                )}
              </div>
            </div>

            <div className="flex items-center text-white/60 text-sm mb-6">
              <Clock size={14} className="mr-1" />
              Available {otherUser.availability}
            </div>

            <Link
              to={`/user/${otherUser.id}`}
              className="btn-primary w-full flex items-center justify-center space-x-2 py-3"
            >
              <MessageSquare size={16} />
              <span>View Profile</span>
            </Link>
          </div>
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-20">
          <div className="w-32 h-32 bg-white/5 rounded-3xl flex items-center justify-center mx-auto mb-8">
            <Users className="text-white/40" size={48} />
          </div>
          <h3 className="text-3xl font-bold text-white mb-4">No users found</h3>
          <p className="text-white/60 text-lg max-w-md mx-auto">
            Try adjusting your search criteria or explore all available users
          </p>
        </div>
      )}
    </div>
  );
}