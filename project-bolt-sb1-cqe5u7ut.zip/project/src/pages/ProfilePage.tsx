import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Save, X, Plus, Trash2, Camera, ArrowLeft, User, MapPin, Clock, Eye } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const [formData, setFormData] = useState({
    name: user?.name || '',
    location: user?.location || '',
    availability: user?.availability || 'weekends',
    isPublic: user?.isPublic !== false,
    bio: user?.bio || ''
  });
  const [skillsOffered, setSkillsOffered] = useState<string[]>(user?.skillsOffered || []);
  const [skillsWanted, setSkillsWanted] = useState<string[]>(user?.skillsWanted || []);
  const [newSkillOffered, setNewSkillOffered] = useState('');
  const [newSkillWanted, setNewSkillWanted] = useState('');

  const handleSave = () => {
    updateProfile({
      ...formData,
      skillsOffered,
      skillsWanted
    });
    alert('Profile saved successfully!');
  };

  const handleDiscard = () => {
    setFormData({
      name: user?.name || '',
      location: user?.location || '',
      availability: user?.availability || 'weekends',
      isPublic: user?.isPublic !== false,
      bio: user?.bio || ''
    });
    setSkillsOffered(user?.skillsOffered || []);
    setSkillsWanted(user?.skillsWanted || []);
  };

  const addSkillOffered = () => {
    if (newSkillOffered.trim() && !skillsOffered.includes(newSkillOffered.trim())) {
      setSkillsOffered([...skillsOffered, newSkillOffered.trim()]);
      setNewSkillOffered('');
    }
  };

  const addSkillWanted = () => {
    if (newSkillWanted.trim() && !skillsWanted.includes(newSkillWanted.trim())) {
      setSkillsWanted([...skillsWanted, newSkillWanted.trim()]);
      setNewSkillWanted('');
    }
  };

  const removeSkillOffered = (skill: string) => {
    setSkillsOffered(skillsOffered.filter(s => s !== skill));
  };

  const removeSkillWanted = (skill: string) => {
    setSkillsWanted(skillsWanted.filter(s => s !== skill));
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 fade-in">
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-5xl font-black text-white mb-2">
            <span className="gradient-text">Edit</span> Profile
          </h1>
          <p className="text-xl text-white/70">Update your skills and information</p>
        </div>
        <div className="flex items-center space-x-4">
          <button
            onClick={handleSave}
            className="btn-primary flex items-center space-x-2"
          >
            <Save size={18} />
            <span>Save Changes</span>
          </button>
          <button
            onClick={handleDiscard}
            className="btn-secondary flex items-center space-x-2"
          >
            <X size={18} />
            <span>Discard</span>
          </button>
          <Link to="/dashboard" className="btn-ghost flex items-center space-x-2">
            <ArrowLeft size={18} />
            <span>Back</span>
          </Link>
        </div>
      </div>

      {/* Profile Form */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Profile Info */}
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card p-8">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
              <User className="mr-3 text-blue-400" size={24} />
              Basic Information
            </h2>
            <div className="space-y-6">
              <div>
                <label className="block text-white/80 font-semibold mb-3">Full Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="input-modern w-full text-lg py-4"
                  placeholder="Your full name"
                />
              </div>

              <div>
                <label className="block text-white/80 font-semibold mb-3">Location</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="input-modern w-full pl-12 text-lg py-4"
                    placeholder="Your city or region"
                  />
                </div>
              </div>

              <div>
                <label className="block text-white/80 font-semibold mb-3">Bio</label>
                <textarea
                  value={formData.bio}
                  onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  rows={4}
                  className="input-modern w-full resize-none text-lg py-4"
                  placeholder="Tell others about yourself and your interests..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-white/80 font-semibold mb-3">Availability</label>
                  <div className="relative">
                    <Clock className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
                    <select
                      value={formData.availability}
                      onChange={(e) => setFormData({ ...formData, availability: e.target.value })}
                      className="input-modern w-full pl-12 text-lg py-4"
                    >
                      <option value="weekends">Weekends</option>
                      <option value="evenings">Evenings</option>
                      <option value="weekdays">Weekdays</option>
                      <option value="flexible">Flexible</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-white/80 font-semibold mb-3">Profile Visibility</label>
                  <div className="relative">
                    <Eye className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
                    <select
                      value={formData.isPublic ? 'public' : 'private'}
                      onChange={(e) => setFormData({ ...formData, isPublic: e.target.value === 'public' })}
                      className="input-modern w-full pl-12 text-lg py-4"
                    >
                      <option value="public">Public - Visible to all</option>
                      <option value="private">Private - Hidden</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Skills Section */}
          <div className="glass-card p-8">
            <h2 className="text-2xl font-bold text-white mb-6">Skills Management</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <label className="block text-emerald-400 font-bold text-lg mb-4">Skills You Offer</label>
                <div className="flex flex-wrap gap-2 mb-4 min-h-[60px] p-4 bg-white/5 rounded-xl border border-white/10">
                  {skillsOffered.map((skill) => (
                    <div key={skill} className="skill-tag skill-offered flex items-center space-x-2">
                      <span>{skill}</span>
                      <button
                        onClick={() => removeSkillOffered(skill)}
                        className="text-emerald-300 hover:text-red-400 transition-colors"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  {skillsOffered.length === 0 && (
                    <p className="text-white/40 italic">No skills added yet</p>
                  )}
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newSkillOffered}
                    onChange={(e) => setNewSkillOffered(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addSkillOffered()}
                    className="input-modern flex-1"
                    placeholder="Add a skill you can teach"
                  />
                  <button
                    onClick={addSkillOffered}
                    className="btn-secondary px-4"
                  >
                    <Plus size={20} />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-purple-400 font-bold text-lg mb-4">Skills You Want</label>
                <div className="flex flex-wrap gap-2 mb-4 min-h-[60px] p-4 bg-white/5 rounded-xl border border-white/10">
                  {skillsWanted.map((skill) => (
                    <div key={skill} className="skill-tag skill-wanted flex items-center space-x-2">
                      <span>{skill}</span>
                      <button
                        onClick={() => removeSkillWanted(skill)}
                        className="text-purple-300 hover:text-red-400 transition-colors"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  {skillsWanted.length === 0 && (
                    <p className="text-white/40 italic">No skills added yet</p>
                  )}
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newSkillWanted}
                    onChange={(e) => setNewSkillWanted(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && addSkillWanted()}
                    className="input-modern flex-1"
                    placeholder="Add a skill you want to learn"
                  />
                  <button
                    onClick={addSkillWanted}
                    className="btn-secondary px-4"
                  >
                    <Plus size={20} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Profile Photo & Stats */}
        <div className="space-y-8">
          <div className="glass-card p-8 text-center">
            <h2 className="text-xl font-bold text-white mb-6">Profile Photo</h2>
            <div className="relative inline-block mb-6">
              <img
                src={user?.profileImage || 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400'}
                alt="Profile"
                className="w-48 h-48 rounded-3xl object-cover border-4 border-white/20"
              />
              <button className="absolute bottom-4 right-4 w-14 h-14 gradient-primary rounded-2xl flex items-center justify-center hover:scale-110 transition-transform shadow-lg">
                <Camera className="text-white" size={20} />
              </button>
            </div>
            <p className="text-white/60 text-sm">
              Click the camera icon to update your photo
            </p>
          </div>

          {/* Profile Stats */}
          <div className="glass-card p-8">
            <h2 className="text-xl font-bold text-white mb-6">Profile Stats</h2>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-white/60">Rating</span>
                <span className="text-yellow-400 font-bold text-lg">{user?.rating?.toFixed(1)}/5.0</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Skills Offered</span>
                <span className="text-emerald-400 font-bold text-lg">{skillsOffered.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Skills Wanted</span>
                <span className="text-purple-400 font-bold text-lg">{skillsWanted.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60">Profile Status</span>
                <span className={`font-bold ${formData.isPublic ? 'text-green-400' : 'text-orange-400'}`}>
                  {formData.isPublic ? 'Public' : 'Private'}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Tips */}
          <div className="glass-card p-8">
            <h2 className="text-xl font-bold text-white mb-4">Profile Tips</h2>
            <div className="space-y-3 text-sm text-white/70">
              <p>• Add 3-5 skills you're confident teaching</p>
              <p>• Be specific about what you want to learn</p>
              <p>• Write a compelling bio to attract matches</p>
              <p>• Keep your availability updated</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}