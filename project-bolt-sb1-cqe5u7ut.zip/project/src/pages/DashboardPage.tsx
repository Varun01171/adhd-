import React from 'react';
import { Link } from 'react-router-dom';
import { Users, MessageSquare, Star, TrendingUp, ArrowRight, Zap, Target, Award } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export default function DashboardPage() {
  const { user } = useAuth();
  const { getReceivedRequests, getSentRequests, getAllUsers } = useData();

  const receivedRequests = getReceivedRequests();
  const sentRequests = getSentRequests();
  const allUsers = getAllUsers();

  const pendingReceived = receivedRequests.filter(req => req.status === 'pending').length;
  const acceptedRequests = [...receivedRequests, ...sentRequests].filter(req => req.status === 'accepted').length;

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 fade-in">
      <div className="mb-12">
        <h1 className="text-5xl font-black text-white mb-4">
          Welcome back, <span className="gradient-text">{user?.name}</span>!
        </h1>
        <p className="text-xl text-white/70">
          Here's what's happening with your skill exchanges
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <div className="glass-card-hover p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white/60 text-sm font-medium">Pending Requests</p>
              <p className="text-4xl font-black text-white">{pendingReceived}</p>
            </div>
            <div className="w-16 h-16 bg-blue-500/20 rounded-2xl flex items-center justify-center">
              <MessageSquare className="text-blue-400" size={28} />
            </div>
          </div>
          <div className="text-sm text-blue-400">+2 from last week</div>
        </div>

        <div className="glass-card-hover p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white/60 text-sm font-medium">Active Exchanges</p>
              <p className="text-4xl font-black text-white">{acceptedRequests}</p>
            </div>
            <div className="w-16 h-16 bg-green-500/20 rounded-2xl flex items-center justify-center">
              <TrendingUp className="text-green-400" size={28} />
            </div>
          </div>
          <div className="text-sm text-green-400">+1 this month</div>
        </div>

        <div className="glass-card-hover p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white/60 text-sm font-medium">Available Users</p>
              <p className="text-4xl font-black text-white">{allUsers.length}</p>
            </div>
            <div className="w-16 h-16 bg-purple-500/20 rounded-2xl flex items-center justify-center">
              <Users className="text-purple-400" size={28} />
            </div>
          </div>
          <div className="text-sm text-purple-400">Growing community</div>
        </div>

        <div className="glass-card-hover p-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-white/60 text-sm font-medium">Your Rating</p>
              <p className="text-4xl font-black text-white">{user?.rating?.toFixed(1)}</p>
            </div>
            <div className="w-16 h-16 bg-yellow-500/20 rounded-2xl flex items-center justify-center">
              <Star className="text-yellow-400" size={28} />
            </div>
          </div>
          <div className="text-sm text-yellow-400">Excellent rating!</div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <div className="glass-card p-8">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Zap className="mr-3 text-blue-400" size={28} />
            Quick Actions
          </h2>
          <div className="space-y-4">
            <Link
              to="/discovery"
              className="flex items-center justify-between p-6 bg-gradient-to-r from-blue-500/10 to-purple-500/10 rounded-2xl hover:from-blue-500/20 hover:to-purple-500/20 transition-all duration-200 border border-blue-500/20 hover:border-blue-500/40 group"
            >
              <div>
                <h3 className="font-bold text-white text-lg">Find Skills to Learn</h3>
                <p className="text-white/60">Discover people with skills you want</p>
              </div>
              <div className="w-12 h-12 gradient-primary rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Users className="text-white" size={20} />
              </div>
            </Link>

            <Link
              to="/profile"
              className="flex items-center justify-between p-6 bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-2xl hover:from-green-500/20 hover:to-emerald-500/20 transition-all duration-200 border border-green-500/20 hover:border-green-500/40 group"
            >
              <div>
                <h3 className="font-bold text-white text-lg">Update Your Skills</h3>
                <p className="text-white/60">Add new skills or update your profile</p>
              </div>
              <div className="w-12 h-12 gradient-secondary rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Star className="text-white" size={20} />
              </div>
            </Link>

            <Link
              to="/requests"
              className="flex items-center justify-between p-6 bg-gradient-to-r from-orange-500/10 to-pink-500/10 rounded-2xl hover:from-orange-500/20 hover:to-pink-500/20 transition-all duration-200 border border-orange-500/20 hover:border-orange-500/40 group"
            >
              <div>
                <h3 className="font-bold text-white text-lg">Manage Requests</h3>
                <p className="text-white/60">View and respond to swap requests</p>
              </div>
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-pink-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <MessageSquare className="text-white" size={20} />
              </div>
            </Link>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="glass-card p-8">
          <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
            <Target className="mr-3 text-purple-400" size={28} />
            Recent Activity
          </h2>
          <div className="space-y-4">
            {receivedRequests.slice(0, 3).map((request) => (
              <div key={request.id} className="flex items-center space-x-4 p-4 bg-white/5 rounded-xl border border-white/10">
                <div className="w-12 h-12 gradient-primary rounded-xl flex items-center justify-center">
                  <span className="text-white text-sm font-bold">
                    {request.fromUserName.charAt(0)}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="text-white font-medium">
                    {request.fromUserName} wants to learn {request.skillOffered}
                  </p>
                  <p className="text-white/60 text-sm">
                    {new Date(request.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <span className={`px-3 py-1 text-xs rounded-full font-medium ${
                  request.status === 'pending' ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30' :
                  request.status === 'accepted' ? 'bg-green-500/20 text-green-300 border border-green-500/30' :
                  'bg-red-500/20 text-red-300 border border-red-500/30'
                }`}>
                  {request.status}
                </span>
              </div>
            ))}
            {receivedRequests.length === 0 && (
              <div className="text-center py-12">
                <Award className="w-16 h-16 text-white/20 mx-auto mb-4" />
                <p className="text-white/60">
                  No recent activity. Start by discovering new skills!
                </p>
                <Link to="/discovery" className="btn-primary mt-4 inline-flex items-center">
                  Explore Skills
                  <ArrowRight className="ml-2" size={16} />
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Skills Overview */}
      <div className="glass-card p-8">
        <h2 className="text-2xl font-bold text-white mb-6">Your Skills Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-lg font-semibold text-emerald-400 mb-4">Skills You Offer</h3>
            <div className="flex flex-wrap gap-2">
              {user?.skillsOffered.map((skill) => (
                <span key={skill} className="skill-tag skill-offered">
                  {skill}
                </span>
              ))}
              {user?.skillsOffered.length === 0 && (
                <p className="text-white/60">No skills added yet</p>
              )}
            </div>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-purple-400 mb-4">Skills You Want</h3>
            <div className="flex flex-wrap gap-2">
              {user?.skillsWanted.map((skill) => (
                <span key={skill} className="skill-tag skill-wanted">
                  {skill}
                </span>
              ))}
              {user?.skillsWanted.length === 0 && (
                <p className="text-white/60">No skills added yet</p>
              )}
            </div>
          </div>
        </div>
        <div className="mt-6">
          <Link to="/profile" className="btn-secondary inline-flex items-center">
            Update Skills
            <ArrowRight className="ml-2" size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}