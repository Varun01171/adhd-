import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Users, Zap, Shield, Star, Sparkles, Globe, Heart } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-mesh text-white overflow-hidden">
      {/* Navigation */}
      <nav className="relative z-10 p-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 gradient-primary rounded-2xl flex items-center justify-center">
              <Sparkles className="text-white" size={24} />
            </div>
            <div>
              <span className="text-2xl font-bold gradient-text">SkillSwap</span>
              <div className="text-xs text-white/60">Exchange & Grow</div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Link to="/login" className="btn-secondary">
              Sign In
            </Link>
            <Link to="/register" className="btn-primary">
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-20 pb-32">
        <div className="text-center fade-in">
          <div className="floating-animation mb-8">
            <h1 className="text-7xl md:text-9xl font-black mb-6">
              <span className="gradient-text">Skill</span>
              <span className="text-white">Swap</span>
            </h1>
          </div>
          
          <p className="text-xl md:text-2xl text-white/80 mb-12 max-w-4xl mx-auto leading-relaxed slide-up">
            Connect with passionate learners worldwide. Share your expertise, 
            learn new skills, and build meaningful relationships through knowledge exchange.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-20 slide-up">
            <Link to="/register" className="btn-primary text-lg px-10 py-5 pulse-glow group">
              Start Your Journey
              <ArrowRight className="ml-3 group-hover:translate-x-1 transition-transform" size={20} />
            </Link>
            <Link to="/login" className="btn-secondary text-lg px-10 py-5">
              Explore Skills
            </Link>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
            <div className="glass-card-hover p-8 slide-up">
              <div className="w-20 h-20 gradient-primary rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Users className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Global Community</h3>
              <p className="text-white/70 leading-relaxed">
                Connect with skilled individuals from around the world who share your passion for learning and teaching.
              </p>
            </div>

            <div className="glass-card-hover p-8 slide-up" style={{ animationDelay: '0.1s' }}>
              <div className="w-20 h-20 gradient-secondary rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Zap className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Smart Matching</h3>
              <p className="text-white/70 leading-relaxed">
                Our intelligent algorithm connects you with the perfect skill exchange partners based on your interests.
              </p>
            </div>

            <div className="glass-card-hover p-8 slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-3xl flex items-center justify-center mx-auto mb-6">
                <Shield className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold mb-4">Safe & Secure</h3>
              <p className="text-white/70 leading-relaxed">
                Verified profiles, secure messaging, and community ratings ensure a safe learning environment.
              </p>
            </div>
          </div>

          {/* Stats Section */}
          <div className="mt-32 grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center slide-up">
              <div className="text-5xl font-black gradient-text mb-3">15K+</div>
              <div className="text-white/60 font-medium">Active Learners</div>
            </div>
            <div className="text-center slide-up" style={{ animationDelay: '0.1s' }}>
              <div className="text-5xl font-black gradient-text mb-3">800+</div>
              <div className="text-white/60 font-medium">Skills Available</div>
            </div>
            <div className="text-center slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="text-5xl font-black gradient-text mb-3">50K+</div>
              <div className="text-white/60 font-medium">Successful Swaps</div>
            </div>
            <div className="text-center slide-up" style={{ animationDelay: '0.3s' }}>
              <div className="flex items-center justify-center mb-3">
                <span className="text-5xl font-black gradient-text">4.9</span>
                <Star className="text-yellow-400 ml-2" size={32} fill="currentColor" />
              </div>
              <div className="text-white/60 font-medium">User Rating</div>
            </div>
          </div>

          {/* CTA Section */}
          <div className="mt-32 glass-card p-12 slide-up">
            <div className="flex items-center justify-center mb-6">
              <Globe className="text-blue-400 mr-3" size={32} />
              <Heart className="text-pink-400 mx-3" size={32} />
              <Sparkles className="text-purple-400 ml-3" size={32} />
            </div>
            <h2 className="text-4xl font-bold mb-6">Ready to Transform Your Skills?</h2>
            <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
              Join thousands of learners who are already growing their skills through meaningful exchanges.
            </p>
            <Link to="/register" className="btn-primary text-lg px-12 py-5 inline-flex items-center">
              Join SkillSwap Today
              <ArrowRight className="ml-3" size={20} />
            </Link>
          </div>
        </div>
      </div>

      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl floating-animation"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[32rem] h-[32rem] bg-purple-500/10 rounded-full blur-3xl floating-animation" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-3/4 left-1/2 w-64 h-64 bg-pink-500/10 rounded-full blur-3xl floating-animation" style={{ animationDelay: '4s' }}></div>
      </div>
    </div>
  );
}