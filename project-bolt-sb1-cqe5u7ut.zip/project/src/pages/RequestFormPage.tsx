import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, User, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useData } from '../context/DataContext';

export default function RequestFormPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { getAllUsers, sendRequest } = useData();
  const [selectedSkillOffered, setSelectedSkillOffered] = useState('');
  const [selectedSkillWanted, setSelectedSkillWanted] = useState('');
  const [message, setMessage] = useState('');

  const otherUser = getAllUsers().find(u => u.id === id);

  if (!otherUser || !user) {
    return (
      <div className="min-h-screen bg-mesh text-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">User not found</h1>
        </div>
      </div>
    );
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSkillOffered || !selectedSkillWanted) {
      alert('Please select both skills');
      return;
    }

    sendRequest({
      fromUserId: user.id,
      toUserId: otherUser.id,
      skillOffered: selectedSkillOffered,
      skillWanted: selectedSkillWanted,
      message,
      status: 'pending'
    });

    alert('Request sent successfully!');
    navigate('/requests');
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-8 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <button
          onClick={() => navigate(-1)}
          className="btn-ghost flex items-center space-x-2"
        >
          <ArrowLeft size={20} />
          <span>Back</span>
        </button>
        <h1 className="text-3xl font-bold text-white">
          Send Skill Request
        </h1>
        <div></div>
      </div>

      {/* Request Form */}
      <div className="glass-card p-10">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center space-x-4 mb-6">
            <img
              src={user.profileImage}
              alt={user.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20"
            />
            <ArrowRight className="text-white/60" size={24} />
            <img
              src={otherUser.profileImage}
              alt={otherUser.name}
              className="w-16 h-16 rounded-2xl object-cover border-2 border-white/20"
            />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">
            Request skill exchange with {otherUser.name}
          </h2>
          <p className="text-white/60">
            Choose skills to exchange and send your request
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="glass-card p-6">
              <label className="block text-emerald-400 font-bold text-lg mb-4">
                Choose one of your offered skills
              </label>
              <select
                value={selectedSkillOffered}
                onChange={(e) => setSelectedSkillOffered(e.target.value)}
                className="input-modern w-full text-lg py-4"
                required
              >
                <option value="">Select a skill you can teach</option>
                {user.skillsOffered.map((skill) => (
                  <option key={skill} value={skill}>
                    {skill}
                  </option>
                ))}
              </select>
              {selectedSkillOffered && (
                <div className="mt-4">
                  <span className="skill-tag skill-offered text-base">
                    {selectedSkillOffered}
                  </span>
                </div>
              )}
            </div>

            <div className="glass-card p-6">
              <label className="block text-purple-400 font-bold text-lg mb-4">
                Choose one of their offered skills
              </label>
              <select
                value={selectedSkillWanted}
                onChange={(e) => setSelectedSkillWanted(e.target.value)}
                className="input-modern w-full text-lg py-4"
                required
              >
                <option value="">Select a skill you want to learn</option>
                {otherUser.skillsOffered.map((skill: string) => (
                  <option key={skill} value={skill}>
                    {skill}
                  </option>
                ))}
              </select>
              {selectedSkillWanted && (
                <div className="mt-4">
                  <span className="skill-tag skill-wanted text-base">
                    {selectedSkillWanted}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Exchange Preview */}
          {selectedSkillOffered && selectedSkillWanted && (
            <div className="glass-card p-6 bg-blue-500/10 border-blue-500/30">
              <h3 className="text-white font-bold text-lg mb-4 text-center">Exchange Summary</h3>
              <div className="flex items-center justify-center space-x-6">
                <div className="text-center">
                  <p className="text-white/60 text-sm mb-2">You will teach</p>
                  <span className="skill-tag skill-offered font-semibold">
                    {selectedSkillOffered}
                  </span>
                </div>
                <ArrowRight className="text-white/60" size={24} />
                <div className="text-center">
                  <p className="text-white/60 text-sm mb-2">You will learn</p>
                  <span className="skill-tag skill-wanted font-semibold">
                    {selectedSkillWanted}
                  </span>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-white/80 font-bold text-lg mb-4">
              Personal Message (Optional)
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={5}
              className="input-modern w-full resize-none text-lg py-4"
              placeholder="Introduce yourself and explain why you'd like to exchange skills..."
            />
          </div>

          <div className="text-center">
            <button
              type="submit"
              className="btn-primary text-lg px-12 py-4 flex items-center space-x-3 mx-auto"
            >
              <Send size={20} />
              <span>Send Request</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}