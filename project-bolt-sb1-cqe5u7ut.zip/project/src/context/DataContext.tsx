import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

interface SwapRequest {
  id: string;
  fromUserId: string;
  toUserId: string;
  fromUserName: string;
  toUserName: string;
  skillOffered: string;
  skillWanted: string;
  message: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

interface DataContextType {
  requests: SwapRequest[];
  sendRequest: (request: Omit<SwapRequest, 'id' | 'createdAt' | 'fromUserName' | 'toUserName'>) => void;
  respondToRequest: (requestId: string, status: 'accepted' | 'rejected') => void;
  getReceivedRequests: () => SwapRequest[];
  getSentRequests: () => SwapRequest[];
  getAllUsers: () => any[];
}

const DataContext = createContext<DataContextType | undefined>(undefined);

const sampleUsers = [
  {
    id: '1',
    name: 'Marc Demo',
    email: 'marc@demo.com',
    password: 'password',
    skillsOffered: ['JavaScript', 'Python', 'React', 'Node.js'],
    skillsWanted: ['Photoshop', 'Graphic Design', 'UI/UX', 'Figma'],
    location: 'San Francisco, CA',
    availability: 'weekends',
    profileImage: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400',
    isPublic: true,
    rating: 4.8,
    bio: 'Passionate full-stack developer with 5+ years of experience. Love teaching and learning new technologies. Always excited to share knowledge and grow together!'
  },
  {
    id: '2',
    name: 'Michell',
    email: 'michell@demo.com',
    password: 'password',
    skillsOffered: ['Photoshop', 'Illustrator', 'Figma', 'UI/UX Design'],
    skillsWanted: ['JavaScript', 'React', 'Node.js', 'Python'],
    location: 'New York, NY',
    availability: 'evenings',
    profileImage: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
    isPublic: true,
    rating: 4.6,
    bio: 'Creative designer transitioning into frontend development. Excited to share design skills and learn coding. Believer in beautiful, functional interfaces.'
  },
  {
    id: '3',
    name: 'Joe Wills',
    email: 'joe@demo.com',
    password: 'password',
    skillsOffered: ['Machine Learning', 'Data Science', 'Python', 'TensorFlow'],
    skillsWanted: ['Mobile Development', 'Swift', 'Kotlin', 'React Native'],
    location: 'Austin, TX',
    availability: 'flexible',
    profileImage: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
    isPublic: true,
    rating: 4.9,
    bio: 'Data scientist with expertise in ML algorithms. Looking to expand into mobile app development. Love solving complex problems with data-driven solutions.'
  },
  {
    id: '4',
    name: 'Sarah Chen',
    email: 'sarah@demo.com',
    password: 'password',
    skillsOffered: ['Product Management', 'User Research', 'Strategy', 'Analytics'],
    skillsWanted: ['Backend Development', 'Database Design', 'DevOps', 'AWS'],
    location: 'Seattle, WA',
    availability: 'weekdays',
    profileImage: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400',
    isPublic: true,
    rating: 4.7,
    bio: 'Product manager with a passion for creating user-centered experiences. Eager to learn backend technologies to better collaborate with engineering teams.'
  },
  {
    id: '5',
    name: 'Alex Rivera',
    email: 'alex@demo.com',
    password: 'password',
    skillsOffered: ['DevOps', 'AWS', 'Docker', 'Kubernetes'],
    skillsWanted: ['Frontend Development', 'Vue.js', 'TypeScript', 'CSS'],
    location: 'Denver, CO',
    availability: 'weekends',
    profileImage: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400',
    isPublic: true,
    rating: 4.5,
    bio: 'DevOps engineer passionate about infrastructure and automation. Looking to strengthen frontend skills to become a more well-rounded developer.'
  }
];

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [requests, setRequests] = useState<SwapRequest[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    const existingUsers = localStorage.getItem('skillSwapUsers');
    if (!existingUsers) {
      localStorage.setItem('skillSwapUsers', JSON.stringify(sampleUsers));
    }

    const storedRequests = localStorage.getItem('skillSwapRequests');
    if (storedRequests) {
      setRequests(JSON.parse(storedRequests));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('skillSwapRequests', JSON.stringify(requests));
  }, [requests]);

  const sendRequest = (requestData: Omit<SwapRequest, 'id' | 'createdAt' | 'fromUserName' | 'toUserName'>) => {
    const users = JSON.parse(localStorage.getItem('skillSwapUsers') || '[]');
    const fromUser = users.find((u: any) => u.id === requestData.fromUserId);
    const toUser = users.find((u: any) => u.id === requestData.toUserId);

    const newRequest: SwapRequest = {
      ...requestData,
      id: Date.now().toString(),
      fromUserName: fromUser?.name || '',
      toUserName: toUser?.name || '',
      createdAt: new Date().toISOString(),
      status: 'pending'
    };

    setRequests(prev => [...prev, newRequest]);
  };

  const respondToRequest = (requestId: string, status: 'accepted' | 'rejected') => {
    setRequests(prev =>
      prev.map(req =>
        req.id === requestId ? { ...req, status } : req
      )
    );
  };

  const getReceivedRequests = () => {
    return requests.filter(req => req.toUserId === user?.id);
  };

  const getSentRequests = () => {
    return requests.filter(req => req.fromUserId === user?.id);
  };

  const getAllUsers = () => {
    const users = JSON.parse(localStorage.getItem('skillSwapUsers') || '[]');
    return users.filter((u: any) => u.id !== user?.id && u.isPublic);
  };

  return (
    <DataContext.Provider value={{
      requests,
      sendRequest,
      respondToRequest,
      getReceivedRequests,
      getSentRequests,
      getAllUsers
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}